This sample shows how to basically use the masapi core classes to create a MassLoader.

In this sample, we use the CompositeMassLoader to create the files that we want to load. Those are a simple xml containing the
motion data and a picture to animate within this motion xml.

The motion of the picture is created on frame 2 => it shows you how to retrieve the load manager object (Loader, URLLoader, ...) 
from the loaded files.